/* 5035742 */

#include "../include/colaDePrioridad.h"
#include "../include/info.h"
#include "../include/utils.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

struct repCP{
  TInfo *heap;
  nat tope;
  nat capacidad;
  nat *posiciones;
};

TColaDePrioridad crearCP(nat N){
  assert(N > 0);
  TColaDePrioridad cp = new repCP;
  cp->heap = new TInfo[N+1];
  for (nat i = 0; i < N+1; i++){
    cp->heap[i] = NULL;
  }
  cp->posiciones = new nat[N+1];
  cp->tope = 0;
  cp->capacidad = N;

  for (nat i = 0; i<N+1; i++){
    cp->posiciones[i] = 0;
  }
  return cp;
}

nat rangoCP(TColaDePrioridad cp){
  return cp->capacidad;
}

static TColaDePrioridad filtradoAscendente(TColaDePrioridad &cp, nat pos){
  TInfo swap = cp->heap[pos];
  while (pos != 1 && realInfo(cp->heap[pos/2]) > realInfo(swap)){
    cp->heap[pos] = cp->heap[pos/2];
    cp->posiciones[natInfo(cp->heap[pos/2])] = pos;
    pos = pos/2;
  }
  cp->heap[pos] = swap;
  cp->posiciones[natInfo(swap)] = pos;
  return cp;
}

static TColaDePrioridad filtradoDescendente(TColaDePrioridad &cp, nat pos){
  TInfo swap = cp->heap[pos];

  if(pos*2 <= cp->tope){
    while(pos*2 <= cp->tope && realInfo(swap) > realInfo(cp->heap[pos*2])){
      nat p_hijo = pos*2;
      
      if (((pos*2)+1)<=cp->tope && realInfo(cp->heap[(pos*2)+1])<realInfo(cp->heap[pos*2]))
        p_hijo = (pos*2)+1;

      if (realInfo(swap) > realInfo(cp->heap[p_hijo])){
        cp->heap[pos] = cp->heap[p_hijo];
        cp->posiciones[natInfo(cp->heap[p_hijo])] = pos;
        pos = p_hijo;
      }
    }
    cp->heap[pos] = swap;
    cp->posiciones[natInfo(swap)] = pos;
  }
  return cp;
}

TColaDePrioridad insertarEnCP(nat elem, double valor, TColaDePrioridad cp){
  assert((1 <= elem && elem <= rangoCP(cp)) && !estaEnCP(elem, cp));
  cp->tope = cp->tope+1;
  cp->heap[cp->tope] = crearInfo(elem, valor);
  cp->posiciones[elem] = cp->tope;
  cp = filtradoAscendente(cp,cp->tope);
  return cp;
}

bool estaVaciaCP(TColaDePrioridad cp){
  return cp->tope == 0;
}

nat prioritario(TColaDePrioridad cp){
  assert(!estaVaciaCP(cp));
  return natInfo(cp->heap[1]);
}

TColaDePrioridad eliminarPrioritario(TColaDePrioridad cp){
  assert(!estaVaciaCP(cp));
  if (cp->tope == 1){
    cp->posiciones[natInfo(cp->heap[1])] = 0;
    liberarInfo(cp->heap[1]);
    cp->heap[1] = NULL;
    cp->tope = 0;
  } else{
    cp->posiciones[natInfo(cp->heap[1])] = 0; 
    liberarInfo(cp->heap[1]);
    cp->heap[1] = cp->heap[cp->tope];
    cp->posiciones[natInfo(cp->heap[cp->tope])] = 1;
    cp->tope = cp->tope-1;
    if(cp->tope > 1){
      cp = filtradoDescendente(cp,1);
    }
  }
  return cp;
}

bool estaEnCP(nat elem, TColaDePrioridad cp){
  if (estaVaciaCP(cp))
    return false;
  else
    return cp->posiciones[elem] != 0;
}

double prioridad(nat elem, TColaDePrioridad cp){
  assert(estaEnCP(elem,cp));
  return realInfo(cp->heap[cp->posiciones[elem]]);
}

TColaDePrioridad actualizarEnCP(nat elem, double valor, TColaDePrioridad cp){
  assert(estaEnCP(elem,cp));

  nat pos = cp->posiciones[elem];
  double valor_ant = realInfo(cp->heap[pos]);
  liberarInfo(cp->heap[pos]); 
  cp->heap[pos] = crearInfo(elem, valor);;

  if (valor_ant > valor)
    cp = filtradoAscendente(cp,pos);
  else if (valor_ant < valor)
    cp = filtradoDescendente(cp,pos);
  return cp;
}

void liberarCP(TColaDePrioridad cp){
  for (nat i = 0; i <= cp->capacidad; i++){
    if (cp->heap[i] != NULL){
      liberarInfo(cp->heap[i]);
    }
  }
  delete [] cp->heap;
  delete [] cp->posiciones;
  delete cp;
}
